from django.contrib import admin
from django.urls import path, include

from django.conf import settings
from django.conf.urls.static import static
from . import views
urlpatterns = [
    path('', views.home, name='home'),
    
    path('admin/', admin.site.urls),
    path('doctor/', include('doctor.urls')),
    path('lab/', include('lab.urls')),
    path('patient/', include('patient.urls')),
    path('pharmacy/', include('pharmacy.urls')),
    path('superadmin/', views.superadmin_pannel, name='superadmin_pannel'),
    path('superadmin/login/', views.superadmin_login, name='superadmin_login'),
    path('superadmin/logout/', views.superadmin_logout, name='superadmin_logout'),
    path('superadmin/add_doctor/', views.add_super_doctor, name='add_super_doctor'),
    path('view_all_doctors/', views.view_all_doctors, name='view_all_doctors'),
    path('view_hospitals/', views.view_hospitals, name='view_hospitals'),
    path('superadmin/add_hospital/', views.add_hospital, name='add_hospital'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)