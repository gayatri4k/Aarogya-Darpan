from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from doctor.models import Doctor, Hospital, Advertisement  # Add this import at the top
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password

def superadmin_pannel(request):
    if request.user.is_authenticated:
        hospitals_count = Hospital.objects.count()
        doctors_count = Doctor.objects.count()
        return render(request, 'super_user/index.html',{'hospitals_count': hospitals_count, 'doctors_count': doctors_count})
    return redirect('superadmin_login')

def superadmin_login(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None and user.is_superuser:
                login(request, user)
                request.session['name'] = user.username
                return redirect('superadmin_pannel')
            else:
                messages.error(request, 'Invalid credentials or not a superuser')
        return render(request, 'super_user/login.html')
    else:
        return redirect('superadmin_pannel')

def superadmin_logout(request):
        logout(request)
        return redirect('superadmin_login')

def add_super_doctor(request):
    hospitals = Hospital.objects.all()
    if request.method == 'POST':
        try:
            aadhar = request.POST['aadhar']
            email = request.POST['email']
            password = make_password(request.POST['password'])
            hospital_id = request.POST.get('hospital')
            
            if not hospital_id:
                messages.error(request, 'Please select a hospital')
                return render(request, 'super_user/add_doctor.html', {'hospitals': hospitals})
            
            avatar = request.FILES['avatar']
            certificate = request.FILES['certificate']
            
            avatar.name = f'doctor_{aadhar}_avatar.{avatar.name.split(".")[-1]}'
            certificate.name = f'doctor_{aadhar}_certificate.{certificate.name.split(".")[-1]}'

            
            if Doctor.objects.filter(aadhar=aadhar).exists():
                messages.error(request, 'aadhar already exists')
            elif Doctor.objects.filter(email=email).exists():
                messages.error(request, 'Email already exists')
            else:
                hospital = Hospital.objects.get(hospital_id=hospital_id)
                doctor = Doctor(
                    first_name=request.POST['first_name'],
                    last_name=request.POST['last_name'],
                    aadhar=aadhar,
                    email=email,
                    password=password,
                    dob=request.POST['dob'],
                    gender=request.POST['gender'],
                    address=request.POST['address'],
                    country=request.POST['country'],
                    city=request.POST['city'],
                    state=request.POST['state'],
                    postal_code=request.POST['postal_code'],
                    phone=request.POST['phone'],
                    avatar=avatar,
                    certificate=certificate,
                    hospital=hospital,  # Assign hospital object
                    education=request.POST['education']
                )
                doctor.save()
                messages.success(request, 'Doctor added successfully')
                return render(request, 'super_user/add_doctor.html', {'hospitals': hospitals})
        except Hospital.DoesNotExist:
            messages.error(request, 'Selected hospital does not exist')
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')
    
    return render(request, 'super_user/add_doctor.html', {'hospitals': hospitals})

def view_all_doctors(request):
    doctors = Doctor.objects.all()
    return render(request, 'super_user/view_all_doctors.html', {'doctors': doctors})

def view_hospitals(request):
    hospitals = Hospital.objects.all()
    return render(request, 'super_user/view_hospitals.html', {'hospitals': hospitals})

def add_hospital(request):
        # if request.user.is_authenticated and request.user.is_superuser:
            if request.method == 'POST':
                hospital = Hospital(
                    name=request.POST['name'],
                    address=request.POST['address'],
                    country=request.POST['country'],
                    city=request.POST['city'],
                    state=request.POST['state'],
                    postal_code=request.POST['postal_code']
                )
                hospital.save()
                messages.success(request, 'Hospital added successfully ')
            return render(request, 'super_user/add_hospital.html')
        # return redirect('superadmin_login')
    
def home(request):
    # Get the latest 3 active advertisements
    advertisements = Advertisement.objects.filter(is_active=True).order_by('-created_at')[:6]
    return render(request, 'home.html', {'advertisements': advertisements})
