from django.shortcuts import render, redirect 
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from .models import Lab
from patient.models import Test
from django.db.models import Q

def lab_login(request):
    if lab_login in request.session:
        return redirect('lab_panel')
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        try:
            lab = Lab.objects.get(email=email)
            if check_password(password, lab.password):
                request.session['lab_id'] = lab.lab_id
                request.session['hospital_id'] = lab.hospital_id
                request.session['lab_name'] = lab.lab_name
                messages.success(request, 'Login successful')
                return redirect('lab_panel')
            else:
                messages.error(request, 'Invalid password')
                return render(request, 'lab/lab_login.html')
        except Lab.DoesNotExist:
            messages.error(request, 'Invalid Lab ID')
            return render(request, 'lab/lab_login.html')
            
    return render(request, 'lab/lab_login.html')

def lab_panel(request):
    if 'lab_id' not in request.session:
        return redirect('lab_login')
    test_count = Test.objects.filter().count()
    pending_tests = Test.objects.filter(status='Pending').count()
    completed_tests = Test.objects.filter(status='Completed').count()
    return render(request, 'lab/index.html', {'test_count': test_count, 'pending_tests': pending_tests, 'completed_tests': completed_tests})

def lab_register(request):
    if request.method == 'POST':
        lab_id = request.POST.get('lab_id')
        lab_name = request.POST.get('lab_name')
        lab_owner_name = request.POST.get('lab_owner_name')
        owner_aadhaar = request.POST.get('owner_aadhaar')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        postal_code = request.POST.get('postal_code')
        phone_number = request.POST.get('phone_number')
        hospital = Hospital.objects.get(hospital_id=request.POST.get('hospital_id'))
        # Validate required fields
        # if not all([lab_id, lab_name, lab_owner_name, owner_aadhaar, email, password, phone_number]):
        #     messages.error(request, 'Please fill all required fields')
        #     return redirect('lab_register')

        # Check passwords match  
        if password != confirm_password:
            messages.error(request, 'Passwords do not match')
            return redirect('lab_register')

        # Check existing lab
        if Lab.objects.filter(lab_id=lab_id).exists():
            messages.error(request, 'Lab ID already exists')
            return redirect('lab_register')

        if Lab.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
            return redirect('lab_register')

        if Lab.objects.filter(owner_aadhaar=owner_aadhaar).exists():
            messages.error(request, 'Owner Aadhaar already exists')
            return redirect('lab_register')

        # Create lab
        try:
            Lab.objects.create(
                lab_id=lab_id,
                lab_name=lab_name,
                lab_owner_name=lab_owner_name,
                owner_aadhaar=owner_aadhaar,
                email=email,
                password=make_password(password),
                address=address,
                city=city, 
                state=state,
                postal_code=postal_code,
                phone_number=phone_number,
                hospital=hospital                
            ).save()
            messages.success(request, 'Lab registered successfully')
            return redirect('lab_login')
        except Exception as e:
            messages.error(request, f'Error registering lab: {str(e)}')
            return redirect('lab_register')

    return render(request, 'lab/lab_register.html')

def lab_logout(request):
    if 'lab_id' in request.session:
        del request.session['lab_id']
    return redirect('lab_login')

def lab_profile(request):
    if 'lab_id' not in request.session:
        return redirect('lab_login')
    lab = Lab.objects.get(lab_id=request.session['lab_id'])
    return render(request, 'lab/lab_profile.html', {'lab': lab})

def edit_lab_profile(request):
    if 'lab_id' not in request.session:
        return redirect('lab_login')
    lab = Lab.objects.get(lab_id=request.session['lab_id'])
    if request.method == 'POST':
        lab.lab_name = request.POST.get('lab_name')
        lab.lab_owner_name = request.POST.get('lab_owner_name')
        lab.email = request.POST.get('email')
        lab.address = request.POST.get('address')
        lab.city = request.POST.get('city')
        lab.state = request.POST.get('state')
        lab.postal_code = request.POST.get('postal_code')
        lab.phone_number = request.POST.get('phone_number')
        lab.save()
        messages.success(request, 'Profile updated successfully')
        return redirect('lab_profile')
    return render(request, 'lab/lab_edit_profile.html', {'lab': lab})

def change_lab_password(request):
    if 'lab_id' not in request.session:
        return redirect('lab_login')
    lab = Lab.objects.get(lab_id=request.session['lab_id'])
    if request.method == 'POST':
        current_password = request.POST.get('current_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        if not check_password(current_password, lab.password):
            messages.error(request, 'Invalid current password')
            return redirect('change_lab_password')
        if new_password != confirm_password:
            messages.error(request, 'Passwords do not match')
            return redirect('change_lab_password')
        lab.password = make_password(new_password)
        lab.save()
        messages.success(request, 'Password changed successfully')
        return redirect('lab_profile')
    return render(request, 'lab/change_lab_password.html', {'lab': lab})

def view_lab_reports(request):
    if 'lab_id' not in request.session:
        return redirect('lab_login')
    lab = Lab.objects.get(lab_id=request.session['lab_id'])
    if request.method == 'POST':
        test = Test.objects.get(id=request.POST.get('test_id'))
        report = request.FILES['report_file']
        report.name = f'test_{test.id}_{test.patient.aadhar}.{report.name.split(".")[-1]}'
        test.report = report
        test.status = 'Completed'
        test.lab = lab
        test.save()
        messages.success(request, 'Report added successfully')
        return redirect('view_lab_reports')
    
    
    tests = Test.objects.all()
    return render(request, 'lab/view_lab_reports.html', {'lab': lab, 'tests': tests})

def lab_upload_report(request, test_id):
    pass
#     if 'lab_id' not in request.session:
#         return redirect('lab_login')
    
#     return render(request, 'lab/add_report.html', {'lab': lab, 'test': test})

def view_patients(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    
    # Get search query from request
    search_query = request.GET.get('search', '')
    city = request.GET.get('city', '')
    
    # Start with all patients
    patients = Patient.objects.all()
    
    # Apply search filter if provided
    if search_query:
        patients = patients.filter(
            Q(first_name__icontains=search_query) | 
            Q(last_name__icontains=search_query) |
            Q(aadhar__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(phone__icontains=search_query) |
            Q(address__icontains=search_query)
        )
    
    # Apply city filter if provided
    if city:
        patients = patients.filter(city=city)
    
    # Get all cities for filter dropdown
    cities = Patient.objects.values_list('city', flat=True).distinct()
    
    return render(request, 'doctor/view_patients.html', {'patients': patients, 'cities': cities})

def view_pharmacies(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    
    # Get search query from request
    search_query = request.GET.get('search', '')
    city = request.GET.get('city', '')
    
    # Start with pharmacies in the current hospital
    pharmacies = Pharmacy.objects.filter(hospital=request.session['hospital_id'])
    
    # Apply search filter if provided
    if search_query:
        pharmacies = pharmacies.filter(
            Q(pharmacy_name__icontains=search_query) | 
            Q(owner_name__icontains=search_query) |
            Q(owner_aadhar__icontains=search_query) |
            Q(phone_number__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(address__icontains=search_query)
        )
    
    # Apply city filter if provided
    if city:
        pharmacies = pharmacies.filter(city=city)
    
    # Get all cities for filter dropdown
    cities = Pharmacy.objects.filter(hospital=request.session['hospital_id']).values_list('city', flat=True).distinct()
    
    return render(request, 'doctor/view_pharmacies.html', {'pharmacies': pharmacies, 'cities': cities})

def view_labs(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    
    # Get search query from request
    search_query = request.GET.get('search', '')
    city = request.GET.get('city', '')
    
    # Start with labs in the current hospital
    labs = Lab.objects.filter(hospital_id=request.session['hospital_id'])
    
    # Apply search filter if provided
    if search_query:
        labs = labs.filter(
            Q(lab_name__icontains=search_query) | 
            Q(lab_owner_name__icontains=search_query) |
            Q(owner_aadhaar__icontains=search_query) |
            Q(phone_number__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(address__icontains=search_query)
        )
    
    # Apply city filter if provided
    if city:
        labs = labs.filter(city=city)
    
    # Get all cities for filter dropdown
    cities = Lab.objects.filter(hospital_id=request.session['hospital_id']).values_list('city', flat=True).distinct()
    
    return render(request, 'doctor/view_labs.html', {'labs': labs, 'cities': cities})