from django.contrib import admin

# Register your models here.
from .models import Lab

admin.site.register(Lab)
