from django.db import models
from doctor.models import Hospital

class Lab(models.Model):
    lab_id = models.CharField(max_length=100, unique=True)
    lab_name = models.CharField(max_length=100)
    lab_owner_name = models.CharField(max_length=100)
    owner_aadhaar = models.CharField(max_length=12, unique=True)
    password = models.CharField(max_length=100, default=None)
    address = models.TextField()
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    phone_number = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    hospital = models.ForeignKey(Hospital, on_delete=models.CASCADE, default=None)

    def __str__(self):
        return self.lab_name