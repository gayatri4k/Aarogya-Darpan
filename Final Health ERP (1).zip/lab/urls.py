
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.lab_panel, name='lab_panel'),
    path('login/', views.lab_login, name='lab_login'),
    path('logout/', views.lab_logout, name='lab_logout'),
    path('register/', views.lab_register, name='lab_register'),
    path('profile/', views.lab_profile, name='lab_profile'),
    path('edit_profile/', views.edit_lab_profile, name='edit_lab_profile'),
    path('change_password/', views.change_lab_password, name='change_lab_password'),
    path('view_lab_reports/', views.view_lab_reports, name='view_lab_reports'),
    path('upload_report/<int:test_id>', views.lab_upload_report, name='lab_upload_report'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
