from django.urls import path
from . import views

urlpatterns = [
    path('', views.patient_pannel, name='patient_pannel'),
    path('login/', views.patient_login, name='patient_login'),
    path('register/', views.patient_register, name='patient_register'),
    path('profile/', views.patient_profile, name='patient_profile'),
    path('edit_profile/', views.edit_patient_profile, name='edit_patient_profile'),
    path('change_password/', views.change_patient_password, name='change_patient_password'),
    path('logout/', views.patient_logout, name='patient_logout'),
    path('view_history/', views.view_history, name='view_history'),
    path('prescription_details/<int:prescription_id>/', views.view_prescription_details, name='prescription_details'),
    path('suggested_test/<str:aadhar>', views.view_suggested_test, name='view_suggested_test'),
    
]
