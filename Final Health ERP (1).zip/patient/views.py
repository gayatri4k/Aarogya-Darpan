from django.shortcuts import render, redirect, get_object_or_404
from . models import Patient, Prescription, PrescriptionItem, Test
from django.contrib.auth.hashers import make_password, check_password
from django.contrib import messages
# Create your views here.
def patient_login(request):
    # if 'patient' in request.session:
    #     return redirect('patient_pannel')
    print(request.session.get('patient_id'))
    if request.method == 'POST':
        aadhar = request.POST.get('aadhar')
        print(aadhar)   
        password = request.POST.get('password')
        

        try:
            patient = Patient.objects.get(aadhar=aadhar)
        except Patient.DoesNotExist:
            messages.error(request, 'Invalid Aadhar')
            return redirect('patient_login')
            
        if check_password(password, patient.password):
            patient = Patient.objects.get(aadhar=aadhar)
            request.session['patient_id'] = patient.aadhar
            print(request.session.get('patient_id'))
            messages.success(request, 'Login successful')
            return redirect('patient_pannel')
        else:
            messages.error(request, 'Invalid password')
        # except Patient.DoesNotExist:
        #     messages.error(request, 'Invalid Aadhar')
    
    return render(request, 'patient/patient_login.html')

def patient_logout(request):
    if 'patient' in request.session:
        del request.session['patient_id']
    return redirect('patient_login')

def patient_pannel(request):
    if 'patient_id' not in request.session:
        return redirect('patient_login')
    patient = Patient.objects.get(aadhar=request.session['patient_id'])
    prescriptions_count = (Prescription.objects.filter(patient=patient)).count()
    pending_test_count = (Test.objects.filter(patient=patient, status="Pending")).count()
    completed_test_count = (Test.objects.filter(patient=patient, status="Completed")).count()
    return render(request, 'patient/index.html',{'patient':patient, 'prescriptions_count':prescriptions_count, 'pending_test_count':pending_test_count, 'completed_test_count':completed_test_count})

def patient_register(request):
    if request.method == 'POST':
        aadhar = request.POST.get('aadhar')
        email = request.POST.get('email')

        if Patient.objects.filter(aadhar=aadhar).exists():
            messages.error(request, 'Aadhar already exists')
        elif Patient.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
        else:
            patient = Patient(
                aadhar=aadhar,
                first_name=request.POST.get('first_name'),
                last_name=request.POST.get('last_name'),
                address=request.POST.get('address'),
                email=request.POST.get('email'),
                dob=request.POST.get('dob'),
                gender=request.POST.get('gender'),
                country=request.POST.get('country'),
                city=request.POST.get('city'),
                state=request.POST.get('state'),
                postal_code=request.POST.get('postal_code'),
                phone=request.POST.get('phone'),
                avatar=request.FILES['avatar'],
                password=make_password(request.POST.get('password'))
            )
            patient.save()
            messages.success(request, 'Patient added successfully')
            return redirect('patient_pannel')
    return render(request, 'patient/patient_register.html')

def view_history(request):
    if 'patient_id' not in request.session:
        return redirect('patient_login')
    patient = Patient.objects.get(aadhar=request.session['patient_id'])
    prescriptions = Prescription.objects.filter(patient=patient)
    tests = Test.objects.filter(patient=patient)
    return render(request, 'patient/view_history.html', {'prescriptions':prescriptions, 'tests':tests})



def view_prescription_details(request, prescription_id):
    if 'patient_id' not in request.session:
        return redirect('patient_login')
    
    patient = get_object_or_404(Patient, aadhar=request.session['patient_id'])
    prescription = get_object_or_404(Prescription, prescription_id=prescription_id, patient=patient)
    
    context = {
        'prescription': prescription
    }
    
    return render(request, 'patient/view_prescription_details.html', context)

def view_suggested_test(request, aadhar):
    if 'patient_id' not in request.session:
        return redirect('patient_login')
    patient = get_object_or_404(Patient, aadhar=request.session['patient_id'])   
    return render(request, 'patient/suggest_test.html', {'patient': patient})

def patient_profile(request):
    patient = Patient.objects.get(aadhar=request.session['patient_id'])
    return render(request, 'patient/patient_profile.html', {'patient': patient})

def edit_patient_profile(request):
    if 'patient_id' not in request.session:
        return redirect('patient_login')
    if request.method == 'POST':
        patient = Patient.objects.get(aadhar=request.session['patient_id'])
        patient.first_name = request.POST['first_name']
        patient.last_name = request.POST['last_name']
        patient.dob = request.POST['dob']
        patient.address = request.POST['address']
        patient.country = request.POST['country']
        patient.city = request.POST['city']
        patient.state = request.POST['state']
        patient.postal_code = request.POST['postal_code']
        avatar = request.FILES['avatar']
        if 'avatar' in request.FILES and patient.avatar:
            avatar.name = patient.avatar.name
            patient.avatar.delete(save=False)
            patient.avatar = avatar
        
        patient.phone = request.POST['phone']
        patient.save()
        return render(request, 'patient/patient_profile.html', {'patient': patient})
    patient=Patient.objects.get(aadhar=request.session['patient_id'])   
    return render(request, 'patient/edit_patient_profile.html', {'patient': patient})

def change_patient_password(request):
    return render(request, 'patient/change_patient_password.html')

