from django.db import models
from doctor.models import Doctor
from lab.models import Lab
from django.utils import timezone
from pharmacy.models import Pharmacy
# from pharmacy.models import Pharmacy
class Patient(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    aadhar = models.CharField(max_length=12, primary_key=True, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    dob = models.DateField()
    gender = models.CharField(max_length=10, choices=[('male', 'Male'), ('female', 'Female')])
    address = models.TextField()
    country = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    phone = models.CharField(max_length=15)
    avatar = models.ImageField(upload_to='patient/avatars/')

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    
class Prescription(models.Model):
    prescription_id = models.PositiveIntegerField(unique=True, editable=False)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    date_issued = models.DateTimeField(auto_now_add=True)
    pharmacy = models.ForeignKey(Pharmacy, on_delete=models.CASCADE, default=None, null=True)
    delivered = models.CharField(max_length=3, choices=[('no','No'), ('yes','Yes')] ,default='No')
    def save(self, *args, **kwargs):
        if not self.prescription_id:
            last_prescription = Prescription.objects.aggregate(models.Max('prescription_id'))
            last_id = last_prescription['prescription_id__max'] or 0
            self.prescription_id = last_id + 1
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Prescription {self.prescription_id} for {self.patient.first_name}"

class PrescriptionItem(models.Model):
    prescription = models.ForeignKey(Prescription, related_name='items', on_delete=models.CASCADE)
    tablet = models.CharField(max_length=255)
    morning = models.BooleanField(default=False)
    afternoon = models.BooleanField(default=False)
    evening = models.BooleanField(default=False)
    night = models.BooleanField(default=False)
    quantity = models.PositiveIntegerField()


    def __str__(self):
        return f"{self.tablet} - Qty: {self.quantity}"
    
class Test(models.Model):
    id = models.AutoField(primary_key=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    lab = models.ForeignKey(Lab, on_delete=models.CASCADE, default=None, null=True)
    test_name = models.CharField(max_length=100)
    description = models.TextField()
    status = models.CharField(max_length=20, default='Pending')
    report = models.FileField(upload_to='patient/test_reports/')
    
    def __str__(self):
        return f"{self.patient.first_name} {self.patient.last_name} - {self.doctor.first_name} {self.doctor.last_name}"