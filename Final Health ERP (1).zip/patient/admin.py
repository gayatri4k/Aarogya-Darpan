from django.contrib import admin

# Register your models here.
from .models import Patient, Prescription, Test

admin.site.register(Patient)
admin.site.register(Prescription)
admin.site.register(Test)
