from django.db import models
from doctor.models import Hospital

class Pharmacy(models.Model):
    pharmacy_name = models.CharField(max_length=100)
    owner_name = models.CharField(max_length=100)
    owner_aadhar = models.CharField(max_length=12, unique=True)
    address = models.TextField()
    country = models.CharField(max_length=100, default='India')
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    phone_number = models.CharField(max_length=15)
    password = models.CharField(max_length=100, default=None)
    hospital = models.ForeignKey(Hospital, on_delete=models.CASCADE, default=None)
    
    def __str__(self):
        return self.pharmacy_name