from django.contrib import admin
from .models import Pharmacy

admin.site.register(Pharmacy)