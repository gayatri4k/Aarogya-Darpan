from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from patient.models import Prescription
from pharmacy.models import Pharmacy
from pharmacy.models import Hospital
from django.contrib.auth.hashers import make_password, check_password

def pharmacy_login(request):
    if request.method == 'POST':
        owner_aadhar = request.POST.get('owner_aadhar')
        password = request.POST.get('password')
        print(owner_aadhar, password)
        pharmacy = Pharmacy.objects.get(owner_aadhar=owner_aadhar)
        print(pharmacy)
        if password == pharmacy.password :
            request.session['pharmacy_id'] = pharmacy.id
            request.session['pharmacy_name'] = pharmacy.pharmacy_name
            return redirect('pharmacy_pannel')
        else:
            messages.error(request, 'Invalid credentials')
            return redirect('pharmacy_login')
        
    return render(request, 'pharmacy/pharmacy_login.html')

def pharmacy_pannel(request):
    prescription_count = Prescription.objects.filter().count()
    pending_prescriptions = Prescription.objects.filter(delivered='no').count()
    completed_prescriptions = Prescription.objects.filter(delivered='yes').count()
    return render(request, 'pharmacy/index.html', {'prescription_count': prescription_count, 'pending_prescriptions': pending_prescriptions, 'completed_prescriptions': completed_prescriptions})

def pharmacy_register(request):
    if request.method == 'POST':
        # Get form data

        pharmacy_name = request.POST.get('pharmacyname')
        owner_name = request.POST.get('pharmacyowner_name')
        owner_aadhar = request.POST.get('owner_aadhaar')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        postal_code = request.POST.get('postal_code')
        phone_number = request.POST.get('phone_number')

        hospital = Hospital.objects.get(hospital_id=request.POST.get('hospital'))
        # Check passwords match
        if password != confirm_password:
            messages.error(request, 'Passwords do not match')
            return redirect('add_pharmacy')
            
        # Check for existing pharmacy
        if Pharmacy.objects.filter(pharmacy_id=pharmacy_id).exists():
            messages.error(request, 'Pharmacy ID already exists')
            return redirect('add_pharmacy')
            
        if Pharmacy.objects.filter(owner_aadhar=owner_aadhar).exists():
            messages.error(request, 'Owner Aadhar already registered')
            return redirect('add_pharmacy')
            
        # Create pharmacy
        try:
            Pharmacy.objects.create(
                
                pharmacy_name=pharmacy_name,
                owner_name=owner_name,
                owner_aadhar=owner_aadhar,
                password=password,
                address=address,
                city=city,
                state=state,
                postal_code=postal_code,
                phone_number=phone_number,
                hospital=hospital
            ).save()
            messages.success(request, 'Pharmacy created successfully')
            return redirect('pharmacy_login')
        except Exception as e:
            messages.error(request, f'Error creating pharmacy: {str(e)}')
            return redirect('view_pharmacy') 
    hospitals = Hospital.objects.all()
    return render(request, 'pharmacy/pharmacy_register.html', {'hospitals': hospitals})

def view_pharmacy_prescriptions(request):
    prescriptions = Prescription.objects.all()
    pharmacies = Pharmacy.objects.all()

    if request.method == 'POST':
        prescription_id = request.POST.get('prescription_id')
        
        prescription = get_object_or_404(Prescription, id=prescription_id)
        prescription.status = "Delivered"
        prescription.pharmacy = get_object_or_404(Pharmacy, id=request.session['pharmacy_id']) if pharmacy_id else None
        prescription.save()
        
        messages.success(request, 'Prescription updated successfully')
        return redirect('view_prescriptions')

    return render(request, 'pharmacy/view_prescription.html', {'prescriptions': prescriptions, 'pharmacies': pharmacies})

def pharmacy_prescription_detail(request, prescription_id):
    prescription = get_object_or_404(Prescription, prescription_id=prescription_id)
    return render(request, 'pharmacy/view_prescription_details.html', {'prescription': prescription})


def delivere_prescription(request):
    if request.method == 'POST':
        prescription = get_object_or_404(Prescription, prescription_id=request.POST.get('prescription_id'))
        prescription.delivered = 'yes'
        prescription.save()
    messages.success(request, 'Prescription delivered successfully')
    return redirect('view_pharmacy_prescriptions')

def pharmacy_logout(request):
    try:
        del request.session['pharmacy_id']
    except KeyError:
        pass
    return redirect('pharmacy_login')

def pharmacy_profile(request):
    pharmacy = get_object_or_404(Pharmacy, id=request.session['pharmacy_id'])
    return render(request, 'pharmacy/pharmacy_profile.html', {'pharmacy': pharmacy})

def edit_pharmacy_profile(request):
    pharmacy = get_object_or_404(Pharmacy, id=request.session['pharmacy_id'])
    if request.method == 'POST':
        pharmacy.pharmacy_name = request.POST.get('pharmacy_name')
        pharmacy.owner_name = request.POST.get('pharmacy_owner_name')
        pharmacy.owner_aadhar = request.POST.get('owner_aadhar')
       
        pharmacy.address = request.POST.get('address')
        pharmacy.city = request.POST.get('city')
        pharmacy.state = request.POST.get('state')
        pharmacy.postal_code = request.POST.get('postal_code')
        pharmacy.phone_number = request.POST.get('phone_number')
        pharmacy.save()
        messages.success(request, 'Profile updated successfully')
        return redirect('pharmacy_profile')
    return render(request, 'pharmacy/edit_pharmacy_profile.html', {'pharmacy': pharmacy})   

def change_pharmacy_password(request):
    pharmacy = get_object_or_404(Pharmacy, id=request.session['pharmacy_id'])
    if request.method == 'POST':
        current_password = request.POST.get('current_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        if not current_password == pharmacy.password :
            messages.error(request, 'Current password is incorrect')
            return redirect('change_password')
        if new_password != confirm_password:
            messages.error(request, 'Passwords do not match')
            return redirect('change_password')
        pharmacy.password = new_password
        pharmacy.save()
        messages.success(request, 'Password changed successfully')
        return redirect('pharmacy_profile')
    return render(request, 'pharmacy/change_pharmacy_password.html', {'pharmacy': pharmacy})