from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('', views.pharmacy_pannel, name='pharmacy_pannel'),
    path('login/', views.pharmacy_login, name='pharmacy_login'),
    path('logout/', views.pharmacy_logout, name='pharmacy_logout'),
    path('register/', views.pharmacy_register, name='pharmacy_register'),
    path('profile/', views.pharmacy_profile, name='pharmacy_profile'),
    path('edit_profile/', views.edit_pharmacy_profile, name='edit_pharmacy_profile'),
    path('change_password/', views.change_pharmacy_password, name='change_pharmacy_password'),
    path('view_prescriptions/', views.view_pharmacy_prescriptions, name='view_pharmacy_prescriptions'),
    path('prescription_detail/<int:prescription_id>/', views.pharmacy_prescription_detail, name='pharmacy_prescription_detail'),
    path('delivere_prescription/', views.delivere_prescription, name='delivere_prescription'),
   
]
