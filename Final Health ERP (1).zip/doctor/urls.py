from django.urls import path
from . import views
urlpatterns = [
    # path('', views.home, name='home'),
    path('', views.doctor_pannel, name='doctor_pannel'),    
    path('home', views.doctor_pannel, name='doctor_pannel'),
    path('login/', views.doctor_login, name='doctor_login'),
    path('profile/', views.doctor_profile, name='doctor_profile'),
    path('edit_profile/', views.edit_doctor_profile, name='edit_doctor_profile'),
    path('change_password/', views.change_doctor_password, name='change_doctor_password'),
    path('logout/', views.doctor_logout, name='doctor_logout'),
    path('add_doctor/', views.add_doctor, name='add_doctor'),
    path('delete_doctor/', views.delete_doctor, name='delete_doctor'),
    path('view_doctors/', views.view_doctors, name='view_doctors'),
    path('view_patients/', views.view_patients, name='view_patients'),
    path('add_patient/', views.add_patient, name='add_patient'),
    path('view_labs/', views.view_labs, name='view_labs'),
    path('view_pharmacies/', views.view_pharmacies, name='view_pharmacies'),
    path('add_lab/', views.add_lab, name='add_lab'),
    path('add_pharmacy/', views.add_pharmacy, name='add_pharmacy'),
    path('issue_prescription/<str:aadhar>/', views.issue_prescription, name='issue_prescription'),
    # path('view_prescriptions/', views.view_prescriptions, name='view_prescriptions'),
    path('prescription_details/<int:prescription_id>/', views.view_prescription_details, name='view_prescription_details'),
    path('suggest_test/<str:aadhar>', views.suggest_test, name='suggest_test'),
    path('view_history/<str:aadhar>', views.view_history, name='view_history'),

    path('add_adv/', views.add_adv, name='add_adv'),
    path('add-advertisement/', views.add_advertisement, name='add_advertisement'),
    path('view-advertisements/', views.view_advertisements, name='view_advs'),
    path('delete-advertisement/<int:adv_id>/', views.delete_advertisement, name='delete_advertisement'),

]


