from django.db import models
from django.utils import timezone


class Hospital(models.Model):
    hospital_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, default=None)
    address = models.TextField(default=None)
    country = models.CharField(max_length=100, default=None)
    city = models.CharField(max_length=100, default=None)
    state = models.CharField(max_length=100, default=None)
    postal_code = models.CharField(max_length=20, default=None)


    def __str__(self):
        return self.name


class Doctor(models.Model):
    
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    aadhar = models.CharField(max_length=100, primary_key=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    dob = models.DateField()
    gender = models.CharField(max_length=10, choices=[('male', 'Male'), ('female', 'Female')])
    address = models.TextField()
    country = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    phone = models.CharField(max_length=15)
    avatar = models.ImageField(upload_to='doctor/avatars/')
    certificate = models.FileField(upload_to='doctor/certificates/')
    education = models.CharField(max_length=100)
    hospital = models.ForeignKey('Hospital', on_delete=models.CASCADE, default=None)
    specialization = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Advertisement(models.Model):
    adv_id = models.AutoField(primary_key=True)
    doctor = models.ForeignKey('Doctor', on_delete=models.CASCADE)
    adv_name = models.CharField(max_length=200)
    adv_desc = models.TextField()
    adv_img = models.ImageField(upload_to='advertisements/')
    created_at = models.DateTimeField(default=timezone.now)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'advertisement'