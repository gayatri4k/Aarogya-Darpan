from .models import Doctor, Advertisement  # Add Advertisement to imports
from lab.models import Lab
from pharmacy.models import Pharmacy
from django.contrib import messages
from patient.models import Patient, Prescription, PrescriptionItem, Test
from django.contrib.auth.hashers import make_password, check_password
from .models import Hospital
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from django.utils import timezone
import os


# Create your views here.


def doctor_pannel(request):
    if 'doctor_id' in request.session:
        # hospital = Hospital.objects.get(hospital_id=hospital_id)
        doc_count = Doctor.objects.filter(hospital=request.session['hospital_id']).count()
        lab_count = Lab.objects.filter(hospital=request.session['hospital_id']).count()
        pharmacy_count = Pharmacy.objects.filter(hospital=request.session['hospital_id']).count()
        
        return render(request, 'doctor/index.html', {'doc_count': doc_count, 'labs_count': lab_count, 'pharmacies_count': pharmacy_count})
    return redirect('doctor_login')
    # return render(request, 'doctor/base.html')

def doctor_login(request):
    if 'doctor_id' in request.session:
        return redirect('doctor_pannel')
    if request.method == 'POST':
        aadhar = request.POST['aadhar']
        password = request.POST['password']
        try:
            doctor = Doctor.objects.get(aadhar=aadhar)
            if check_password(password, doctor.password):
                request.session['doctor_id'] = doctor.aadhar
                request.session['doctor_name'] = doctor.first_name
                request.session['hospital_id'] = doctor.hospital_id
                return redirect('doctor_pannel')
            else:
                messages.error(request, 'Invalid password')
        except Doctor.DoesNotExist:
            messages.error(request, 'Invalid aadhar')
    return render(request, 'doctor/doctor_login.html')



def doctor_profile(request):
    doctor = Doctor.objects.get(aadhar=request.session['doctor_id'])
    return render(request, 'doctor/doctor_profile.html', {'doctor': doctor})

def edit_doctor_profile(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    if request.method == 'POST':
        doctor = Doctor.objects.get(aadhar=request.session['doctor_id'])
        doctor.first_name = request.POST['first_name']
        doctor.last_name = request.POST['last_name']
        doctor.dob = request.POST['dob']
        doctor.address = request.POST['address']
        doctor.country = request.POST['country']
        doctor.city = request.POST['city']
        doctor.state = request.POST['state']
        doctor.postal_code = request.POST['postal_code']
        avatar = request.FILES.get('avatar')
        
        if 'avatar' in request.FILES and patient.avatar:
            avatar.name = patient.avatar.name
            patient.avatar.delete(save=False)
            patient.avatar = avatar
        
        doctor.education = request.POST['education']
        doctor.phone = request.POST['phone']
        doctor.save()
        return render(request, 'doctor/doctor_profile.html', {'doctor': doctor})
    
    doctor=Doctor.objects.get(aadhar=request.session['doctor_id'])   
    return render(request, 'doctor/edit_doctor_profile.html', {'doctor': doctor})

def change_doctor_password(request):
    if request.method == 'POST':
        doctor = Doctor.objects.get(aadhar=request.session['doctor_id'])
        old_password = request.POST['current_password']
        new_password = request.POST['new_password']
        confirm_password = request.POST['confirm_password']
        
        if not check_password(old_password, doctor.password):
            messages.error(request, 'Invalid old password')
        elif new_password != confirm_password:
            messages.error(request, 'Passwords do not match')
        else:
            doctor.password = make_password(new_password)
            doctor.save()
            messages.success(request, 'Password changed successfully')
            return redirect('doctor_profile')
    return render(request, 'doctor/change_doctor_password.html')

def add_doctor(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    if request.method == 'POST':
        aadhar = request.POST.get('aadhar')
        email = request.POST['email']
        password = make_password(request.POST['password'])
        avatar = request.FILES['avatar']
        certificate = request.FILES['certificate']
        
        avatar.name = f'doctor_{aadhar}_avatar.{avatar.name.split(".")[-1]}'
        certificate.name = f'doctor_{aadhar}_certificate.{certificate.name.split(".")[-1]}'
        
        
        if Doctor.objects.filter(aadhar=aadhar).exists():
            messages.error(request, 'aadhar already exists')
        elif Doctor.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
        else:
            hospital = Hospital.objects.get(hospital_id = request.session['hospital_id'])
            doctor = Doctor(
                first_name=request.POST['first_name'],
                last_name=request.POST['last_name'],
                aadhar=aadhar,
                email=email,
                password=password,
                dob=request.POST['dob'],
                gender=request.POST['gender'],
                address=request.POST['address'],
                country=request.POST['country'],
                city=request.POST['city'],
                state=request.POST['state'],
                postal_code=request.POST['postal_code'],
                phone=request.POST['phone'],
                avatar=avatar,
                certificate=certificate,
                education=request.POST['education'],
                hospital=hospital
            )
            doctor.save()
            messages.success(request, 'Registration successful')
            return redirect('doctor_pannel')
    hospital = Hospital.objects.all()
    return render(request, 'doctor/add_doctor.html', {'hospital': hospital})

def view_doctors(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
        
    doctors = Doctor.objects.all()
    search_query = request.GET.get('search', '')
    
    if search_query:
        doctors = doctors.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(specialization__icontains=search_query) |
            Q(email__icontains=search_query)
        )
    
    return render(request, 'doctor/view_doctors.html', {
        'doctors': doctors,
        'search_query': search_query
    })

def view_patients(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    
    # Get search query from request
    search_query = request.GET.get('search', '')
    city = request.GET.get('city', '')
    
    # Start with all patients
    patients = Patient.objects.all()
    
    # Apply search filter if provided
    if search_query:
        patients = patients.filter(
            Q(first_name__icontains=search_query) | 
            Q(last_name__icontains=search_query) |
            Q(aadhar__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(phone__icontains=search_query) |
            Q(address__icontains=search_query)
        )
    
    # Apply city filter if provided
    if city:
        patients = patients.filter(city=city)
    
    # Get all cities for filter dropdown
    cities = Patient.objects.values_list('city', flat=True).distinct()
    
    return render(request, 'doctor/view_patients.html', {'patients': patients, 'cities': cities})

def delete_doctor(request, id):
    doctor = Doctor.objects.get(aadhar=id)
    if doctor:      
        doctor.delete()
        messages.success(request, 'Doctor deleted successfully')
    else:
        messages.error(request, 'Doctor not found')
    return redirect('view_doctors')
    
def add_patient(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    if request.method == 'POST':
        aadhar = request.POST['aadhar']
        email = request.POST['email']
        password = make_password(request.POST['password'])
        
        avatar=request.FILES['avatar']
        avatar.name = f'patient_{aadhar}_avatar.{avatar.name.split(".")[-1]}'
        
        if Patient.objects.filter(aadhar=aadhar).exists():
            messages.error(request, 'aadhar already exists')
        elif Patient.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
        else:
            patient = Patient(
                first_name=request.POST['first_name'],
                last_name=request.POST['last_name'],
                aadhar=aadhar,
                email=email,
                password=password,
                dob=request.POST['dob'],
                gender=request.POST['gender'],
                address=request.POST['address'],
                country=request.POST['country'],
                city=request.POST['city'],
                state=request.POST['state'],
                postal_code=request.POST['postal_code'],
                phone=request.POST['phone'],
                avatar=avatar,
            )
            patient.save()
            messages.success(request, 'Patient added successfully')
            return redirect('view_patients')

    return render(request, 'doctor/add_patient.html')

def view_labs(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    
    # Get search query from request
    search_query = request.GET.get('search', '')
    city = request.GET.get('city', '')
    
    # Start with labs in the current hospital
    labs = Lab.objects.filter(hospital_id=request.session['hospital_id'])
    
    # Apply search filter if provided
    if search_query:
        labs = labs.filter(
            Q(lab_name__icontains=search_query) | 
            Q(lab_owner_name__icontains=search_query) |
            Q(owner_aadhaar__icontains=search_query) |
            Q(phone_number__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(address__icontains=search_query)
        )
    
    # Apply city filter if provided
    if city:
        labs = labs.filter(city=city)
    
    # Get all cities for filter dropdown
    cities = Lab.objects.filter(hospital_id=request.session['hospital_id']).values_list('city', flat=True).distinct()
    
    return render(request, 'doctor/view_labs.html', {'labs': labs, 'cities': cities})

def view_pharmacies(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    
    # Get search query from request
    search_query = request.GET.get('search', '')
    city = request.GET.get('city', '')
    
    # Start with pharmacies in the current hospital
    pharmacies = Pharmacy.objects.filter(hospital=request.session['hospital_id'])
    
    # Apply search filter if provided
    if search_query:
        pharmacies = pharmacies.filter(
            Q(pharmacy_name__icontains=search_query) | 
            Q(owner_name__icontains=search_query) |
            Q(owner_aadhar__icontains=search_query) |
            Q(phone_number__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(address__icontains=search_query)
        )
    
    # Apply city filter if provided
    if city:
        pharmacies = pharmacies.filter(city=city)
    
    # Get all cities for filter dropdown
    cities = Pharmacy.objects.filter(hospital=request.session['hospital_id']).values_list('city', flat=True).distinct()
    
    return render(request, 'doctor/view_pharmacies.html', {'pharmacies': pharmacies, 'cities': cities})

def add_lab(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    if request.method == 'POST':
        lab_id = request.POST['lab_id']

        password = make_password(request.POST.get('password'))
        email=request.POST['email']
        if Lab.objects.filter(lab_id=lab_id).exists():
            messages.error(request, 'Lab ID already exists')
        elif Lab.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
        else:
            lab = Lab(
                lab_id=lab_id,
                password=password,
                lab_name=request.POST.get('lab_name'),
                lab_owner_name=request.POST.get('lab_owner_name'),
                owner_aadhaar=request.POST.get('owner_aadhaar'),
                address=request.POST.get('address'),
                city=request.POST.get('city'),
                state=request.POST.get('state'),
                postal_code=request.POST.get('postal_code'),
                phone_number=request.POST.get('phone_number'),
                email=email,
                hospital=Hospital.objects.get(hospital_id=Doctor.objects.get(aadhar=request.session['doctor_id']).hospital_id)
            )
            lab.save()
            messages.success(request, 'Lab added successfully')
            return redirect('view_labs')

    return render(request, 'doctor/add_lab.html')


def add_pharmacy(request):
    if request.method == 'POST':
        # Get form data
        pharmacy_id = request.POST.get('pharmacyid')
        pharmacy_name = request.POST.get('pharmacyname')
        owner_name = request.POST.get('pharmacyowner_name')
        owner_aadhar = request.POST.get('owner_aadhaar')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        postal_code = request.POST.get('postal_code')
        phone_number = request.POST.get('phone_number')

            
        # Check passwords match
        if password != confirm_password:
            messages.error(request, 'Passwords do not match')
            return redirect('add_pharmacy')
            
        # Check for existing pharmacy
        if Pharmacy.objects.filter(pharmacy_id=pharmacy_id).exists():
            messages.error(request, 'Pharmacy ID already exists')
            return redirect('add_pharmacy')
            
        if Pharmacy.objects.filter(owner_aadhar=owner_aadhar).exists():
            messages.error(request, 'Owner Aadhar already registered')
            return redirect('add_pharmacy')
            
        # Create pharmacy
        try:
            Pharmacy.objects.create(
                pharmacy_id=pharmacy_id,
                pharmacy_name=pharmacy_name,
                owner_name=owner_name,
                owner_aadhar=owner_aadhar,
               
                password=make_password(password),
                address=address,
                city=city,
                state=state,
                postal_code=postal_code,
                phone_number=phone_number,
                hospital=Hospital.objects.get(hospital_id=request.session['hospital_id'])
            ).save()
            messages.success(request, 'Pharmacy created successfully')
            return redirect('pharmacy_login')
        except Exception as e:
            messages.error(request, f'Error creating pharmacy: {str(e)}')
            return redirect('view_pharmacy') 
            
    return render(request, 'doctor/add_pharmacy.html')


def doctor_logout(request):
    if 'doctor_id' in request.session:
        del request.session['doctor_id']
    return redirect('doctor_login')

# ...existing code...

def issue_prescription(request, aadhar):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    
    doctor = get_object_or_404(Doctor, aadhar=request.session['doctor_id'])
    patient = get_object_or_404(Patient, aadhar=aadhar)
    
    if request.method == 'POST':
        tablets = request.POST.getlist('tablet[]')
        mornings = request.POST.getlist('morning[]')
        afternoons = request.POST.getlist('afternoon[]')
        evenings = request.POST.getlist('evening[]')
        nights = request.POST.getlist('night[]')
        quantities = request.POST.getlist('quantity[]')
        
        if not tablets:
            messages.error(request, 'Please add at least one tablet.')
            return redirect('issue_prescription', aadhar=aadhar)
        
        if not all(quantities):
            messages.error(request, 'Please enter quantities for all tablets.')
            return redirect('issue_prescription', aadhar=aadhar)
        
        # Create Prescription
        prescription = Prescription.objects.create(
            doctor=doctor,
            patient=patient,
        )
        
        # Iterate over tablets and create PrescriptionItem
        for i in range(len(tablets)):
            tablet_name = tablets[i]
            morning = True if i < len(mornings) and mornings[i] == '1' else False
            afternoon = True if i < len(afternoons) and afternoons[i] == '1' else False
            evening = True if i < len(evenings) and evenings[i] == '1' else False
            night = True if i < len(nights) and nights[i] == '1' else False
            quantity = quantities[i]
            
            PrescriptionItem.objects.create(
                prescription=prescription,
                tablet=tablet_name,
                morning=morning,
                afternoon=afternoon,
                evening=evening,
                night=night,
                quantity=quantity
            )
        
        messages.success(request, f'Prescription {prescription.prescription_id} issued successfully.')
        return redirect('view_history', aadhar=patient.aadhar)  # Ensure this URL exists
        
    return render(request, 'doctor/issue_prescription.html', {'patient': patient})


def suggest_test(request, aadhar):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    doctor = get_object_or_404(Doctor, aadhar=request.session['doctor_id'])
    patient = get_object_or_404(Patient, aadhar=aadhar)
    
    if request.method == 'POST':
        
        test_name = request.POST['test_name']
        description = request.POST['description']
        
        Test.objects.create(
            patient=patient,
            doctor=doctor,
            test_name=test_name,
            description=description
        )
        messages.success(request, 'Test suggested successfully.')
        return redirect('view_patients')
    
    return render(request, 'doctor/suggest_test.html', {'patient': patient})

def view_history(request, aadhar):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    patient = get_object_or_404(Patient, aadhar=aadhar)
    prescriptions = Prescription.objects.filter(patient=patient)
    tests = Test.objects.filter(patient=patient)
    return render(request, 'doctor/view_history.html', {'patient': patient, 'prescriptions': prescriptions, 'tests': tests})
# ...existing code...


def view_prescription_details(request, prescription_id):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
    
    doctor = get_object_or_404(Doctor, aadhar=request.session['doctor_id'])
    prescription = get_object_or_404(Prescription, prescription_id=prescription_id, doctor=doctor)
    
    context = {
        'prescription': prescription
    }
    
    return render(request, 'doctor/view_prescription_details.html', context)

def add_adv(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')

    if request.method == 'POST':
        try:
            doctor = Doctor.objects.get(aadhar=request.session['doctor_id'])
            adv_name = request.POST.get('adv_name')
            adv_desc = request.POST.get('adv_desc')
            adv_img = request.FILES.get('adv_img')

            # Check if advertisement with same name exists for this doctor
            if Advertisement.objects.filter(adv_name=adv_name, doctor=doctor).exists():
                messages.error(request, 'You have already posted an advertisement with this name.')
            else:
                adv = Advertisement(
                    adv_name=adv_name,
                    adv_desc=adv_desc,
                    adv_img=adv_img,
                    doctor=doctor
                )
                adv.save()
                messages.success(request, 'Advertisement added successfully!')
                return redirect('view_advs')

        except Doctor.DoesNotExist:
            messages.error(request, 'Doctor not found.')
            return redirect('doctor_login')
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')

    return render(request, 'doctor/add_adv.html')

def add_advertisement(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')

    if request.method == 'POST':
        try:
            doctor = Doctor.objects.get(aadhar=request.session['doctor_id'])
            adv_name = request.POST.get('ad_name')
            adv_desc = request.POST.get('ad_description')
            adv_img = request.FILES.get('ad_image')

            # Validate inputs
            if not all([adv_name, adv_desc, adv_img]):
                messages.error(request, 'All fields are required.')
                return redirect('add_advertisement')

            # Check for duplicate advertisement name
            if Advertisement.objects.filter(doctor=doctor, adv_name=adv_name).exists():
                messages.error(request, 'An advertisement with this name already exists.')
                return redirect('add_advertisement')

            # Create new advertisement
            advertisement = Advertisement(
                doctor=doctor,
                adv_name=adv_name,
                adv_desc=adv_desc,
                adv_img=adv_img
            )
            advertisement.save()

            messages.success(request, 'Advertisement added successfully!')
            return redirect('view_advertisements')  # Create this view for listing ads

        except Doctor.DoesNotExist:
            messages.error(request, 'Doctor not found.')
            return redirect('doctor_login')
        except Exception as e:
            messages.error(request, f'Error adding advertisement: {str(e)}')
            return redirect('add_advertisement')

    return render(request, 'doctor/add_adv.html')

def view_advertisements(request):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
        
    try:
        doctor = Doctor.objects.get(aadhar=request.session['doctor_id'])
        advertisements = Advertisement.objects.filter(doctor=doctor).order_by('-created_at')
        
        return render(request, 'doctor/view_advertisements.html', {
            'advertisements': advertisements
        })
    except Doctor.DoesNotExist:
        messages.error(request, 'Doctor not found')
        return redirect('doctor_login')
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('doctor_pannel')

def delete_advertisement(request, adv_id):
    if 'doctor_id' not in request.session:
        return redirect('doctor_login')
        
    try:
        doctor = Doctor.objects.get(aadhar=request.session['doctor_id'])
        advertisement = Advertisement.objects.get(adv_id=adv_id, doctor=doctor)
        
        # Delete the image file
        if advertisement.adv_img:
            if os.path.isfile(advertisement.adv_img.path):
                os.remove(advertisement.adv_img.path)
        
        # Delete the advertisement
        advertisement.delete()
        messages.success(request, 'Advertisement deleted successfully')
        
    except Advertisement.DoesNotExist:
        messages.error(request, 'Advertisement not found')
    except Doctor.DoesNotExist:
        messages.error(request, 'Doctor not found')
    except Exception as e:
        messages.error(request, f'Error deleting advertisement: {str(e)}')
        
    return redirect('view_advs')