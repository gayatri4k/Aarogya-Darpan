from django.contrib import admin
# Register your models here.
from .models import Doctor, Hospital

admin.site.register(Doctor)
admin.site.register(Hospital)